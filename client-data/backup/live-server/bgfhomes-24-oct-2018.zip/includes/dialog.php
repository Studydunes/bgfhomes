<div class="modal fade" id="myModal-2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
	  <div class="modal-content">
		  <div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
			  <h4 class="modal-title">Record Delete Confirmation ?</h4>
		  </div>
		  <div class="modal-body">
			  <form role="form" class="form-inline">
				  <div class="form-group">
					 Do you want to delete the record ?
				  </div>
				  <div class="rows" style="float:right; margin-top:15px;">
					<button class="btn btn-danger" type="button" onClick="delete_record()">Delete</button>
					<button class="btn btn-success" type="button" class="close" data-dismiss="modal" aria-hidden="true">Cancel</button>
				  </div>
			  </form>
			  <div style="clear:both"></div>
		  </div>

	  </div>
  </div>
</div> 