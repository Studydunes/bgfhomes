<?php include_once("includes/header.php"); ?>

    <!--container start-->

    <div class="container">

      <div class="row mar-b-50">

        <div class="col-lg-5">

          <div class="about-carousel wow fadeInLeft">

            <img class="img-responsive" src="img/parallax-slider/images/g2.jpg" alt="" style="height: 100%;width: 100%;">
          
          </div>

        </div>

        <div class="col-lg-7 about wow fadeInRight">

           <h3 class="w3l-sub"><strong>Loan & Vaults</strong></h3>

				<p class="sub-p2"><strong>Your secure wealth vaults</strong></p>

				<p class="sub-p3">Bank Giro Finance Homes is an secured multinational banking organisation headquartered in an undisclose location in Singapore, with branches in undisclose locations in Europe and Asian countries. Founded in 1895 by groups of retired goverment secret agents around the globe, and later restructured to offer service strictly to the likes of both active and retired government secret agents of partner country, licenced private detective, UN verified bounty hunters and high profile personel with referal and recomendations from either active or retired government agent of partner country or licenced private detective/investigator</p>

				

				<p class="sub-p3">Bank Giro Finance Homes has been busy in recent years. Not content to be anything less than the best in the anonymous banking industries, it has set out on a mission to take the world anonymous/offshore banking and international investment industries by storm. Today, this anonymous financial institute is said to be the only financial institute that understand the need for secret banking plus its the only bank of its type allowed, approved by united nation and currently authorized and approved to operate and serve in 44 convinced countries around the globe allowing us to operate anonymously while we take care of your secret banking and investment needs.</p>
				
				<p class="sub-p3">Talk to our team, we always happy to hear you out</p>

				<a href="contact.php" class="btn btn-success btn-md"><b>Contact us</b></a>

          </div>

      </div>



    </div>

<?php include_once("includes/footer.php"); ?>

