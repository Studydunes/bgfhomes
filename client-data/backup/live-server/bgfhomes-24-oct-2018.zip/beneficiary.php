<?php 
	include_once("includes/header.php"); 
	require_once('includes/mysql_connection.php');
	
	$account_balance = getBalance($_SESSION['user_details']['user_id']);
	
	$data_con = new MysqlDB();
    $data_con->connect(); 
    $trasfer_record = $data_con->select("*", TRANSFER_LIMIT, 1, true);
	if($_REQUEST['beneficiary_id'])
	{
		//$SQL="SELECT * FROM `beneficiary` WHERE beneficiary_id = $_REQUEST[beneficiary_id]";
		//$rs=mysqli_query($con,$SQL) or die(mysqli_error($con));
		//$data=mysqli_fetch_assoc($rs);
		//select($fields = '*', $table, $conditons = 1, $single = true)
		$data = $data_con->select("*", BENEFICIARY, "beneficiary_id=".$_REQUEST['beneficiary_id']);
	}
    
?>
<script>
		jQuery(function() {
			jQuery( "#beneficiary_date" ).datepicker({
			changeMonth: true,
			changeYear: true,
			yearRange: "0:+1",
			dateFormat: 'd MM,yy'
			});
		});
</script>
    <!--breadcrumbs start-->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-4">
                    <h1>Beneficiary Management</h1>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->
    <div class="registration-bg">
        <div class="container">
            <form  action="lib/beneficiary.php" class="form-signin wow fadeInUp" action="" style="max-width:800px">
                <h2 class="form-signin-heading">Transfer Funds</h2>
				<?php if($_REQUEST['msg']) { ?>
					<div class="alert alert-success fade in" style="margin:10px;">
						<strong><?=$_REQUEST['msg']?></strong>
					</div>
				<?php } ?>
                <div class="login-wrap">         
					<div class="form-group" id="userRole">
						<label for="pwd">Update Transfer Status</label>
						<select  name="beneficiary_status_id" class="form-control" placeholder="Select Month" autofocus=""/>
							<?php echo get_new_optionlist("status","status_id","status_title",$data['beneficiary_status_id']); ?>
						</select>
				    </div>
				    <div class="form-group">
						<label for="pwd">Available Balance is:</label>
						<p class="alert alert-info">
							<strong>$<?= $account_balance; ?></strong>
							<input type="hidden" class="form-control" name="cur_user_account_balance" id="cur_user_account_balance" value="<?= $account_balance; ?>">
						</p>
				    </div>
					<div class="form-group">
						<label for="pwd">Select Currency</label>
						<select name="beneficiary_currency_id" class="form-control" placeholder="Select Currency" autofocus=""/>
							<?php echo get_new_optionlist("currency","currency_id","currency_title",$data['beneficiary_currency_id']); ?>
						</select>
				    </div>
                    <div class="form-group">
						<label for="pwd">Beneficiary Bank Name</label>
						<input required type="text" class="form-control" placeholder="Beneficiary Bank Name" autofocus="" name="beneficiary_bank_name" id="beneficiary_bank_name" value="<?=$data['beneficiary_bank_name']?>">
					</div>
				    <div class="form-group">
						<label for="pwd">Beneficiary Account Number</label>
						<input required type="text" class="form-control" placeholder="Beneficiary Account Number" autofocus="" name="beneficiary_account_number" id="beneficiary_account_number" value="<?=$data['beneficiary_account_number']?>">
				    </div>
					<?php if(!array_key_exists("beneficiary_id", $_REQUEST)) { ?>
						<div class="form-group">
							<label for="pwd">Beneficiary IFSC Code</label>
							<input required type="text" class="form-control" placeholder="Beneficiary IFSC Code" autofocus="" name="beneficiary_ifsc_code" id="beneficiary_ifsc_code" value="<?=$data['beneficiary_ifsc_code']?>">
						</div>
					<?php } else { ?>
							<input type="hidden" class="form-control" placeholder="Beneficiary IFSC Code" autofocus="" name="beneficiary_ifsc_code" id="beneficiary_ifsc_code" value="<?=$data['beneficiary_ifsc_code']?>">
				    <?php } ?>
					<div class="form-group">
						<label for="pwd">Amount</label>
						<input type="number"  min="1" max="<?= $trasfer_record['max_transfer_limit']; ?>" class="form-control" placeholder="Amount" autofocus="" name="beneficiary_amount" id="beneficiary_amount" value="<?=$data['beneficiary_amount']?>">
						<!-- <label id="max_limit" style="color:red;"></label> -->
				    </div>
                    <button class="btn btn-lg btn-login btn-block" type="submit">Deposit Payament</button>
                </div>
                <input type="hidden" name="act" value="save_beneficiary">
				<input type="hidden" name="beneficiary_id" value="<?=$data['beneficiary_id']?>">
				<input type="hidden" name="beneficiary_user_id" value="<?=$data['beneficiary_user_id']?>">
            </form>
        </div>
     </div>
    <!--container end-->
	<script>
	<?php if($_SESSION['user_details']['user_level_id'] != 1)  { ?> 
		$("#userRole").hide();
	<?php } ?>
</script>
<?php include_once("includes/footer.php"); ?>
