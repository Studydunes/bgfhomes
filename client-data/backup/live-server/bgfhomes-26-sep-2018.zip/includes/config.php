<?php $smtpSetting = array(
	'smtp'=>'mail.bgfhomes.com',
	'port'=>26,
	'type'=>'ssl',
	'username'=>'info@bgfhomes.com',
	'password'=>'Bgf#Home@18',
	'from'=>'info@bgfhomes.com',
	'from_name'=>'Bgfhomes'
);?>